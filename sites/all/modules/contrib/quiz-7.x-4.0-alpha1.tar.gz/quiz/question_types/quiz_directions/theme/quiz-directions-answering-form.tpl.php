<?php
/**
 * @file
 * Handles the layout of the quiz_directions answering form.
 *
 *
 * Variables available:
 * - $form
 */
print drupal_render($form);

?>